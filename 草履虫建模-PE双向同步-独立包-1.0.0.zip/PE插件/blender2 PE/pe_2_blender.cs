using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Xml;
using PEPlugin;

public class PE2BlenderReceiver : PEPluginClass {
 public override string Name {get{return "草履虫建模 · PE 双向同步（独立版）";}}
 public override string Version {get{return "2.1.0";}}
 public override string Description {get{return "Blender 接收预览与 PE 回传；先备份再更新 Blender 当前文件中的同步模型";}}
 static ReceiverWindow window;
 public PE2BlenderReceiver(){m_option=new PEPluginOption(false,true,"草履虫建模 · PE 双向同步（独立版）");}
 public override void Run(IPERunArgs args){if(window==null||window.IsDisposed)window=new ReceiverWindow(args);window.Show();window.Activate();}
}
public sealed class ReceiverWindow : Form {
 readonly PreviewInbox inbox=new PreviewInbox(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"CaolvchongPESync","exchange"));
 readonly IPERunArgs args;readonly Timer timer=new Timer();readonly Label status=new Label();
 string lastReturn;
 static string Texture(string value,string folder){return String.IsNullOrEmpty(value)||Path.IsPathRooted(value)?value:Path.GetFullPath(Path.Combine(folder,value));}
 public ReceiverWindow(IPERunArgs hostArgs){
  args=hostArgs;Text="草履虫建模 · PE 双向同步（独立版）";ClientSize=new Size(500,235);
  var explanation=new Label{Left=12,Top=12,Width=475,Height=48,Text="接收 Blender 导出预览；编辑完成后可发送回 Blender。\nBlender 会先备份，再更新当前文件中的同步模型并保存。"};
  var start=new Button{Left=12,Top=66,Width=220,Height=30,Text="开始接收 Blender 预览"};
  var stop=new Button{Left=244,Top=66,Width=110,Height=30,Text="暂停接收"};
  var send=new Button{Left=12,Top=108,Width=342,Height=34,Text="发送回 Blender（备份后更新原文件）"};
  status.SetBounds(12,154,475,70);status.Text="Blender 中需开启 PE 回传接收。未保存的源文件需先保存。";
  start.Click+=(s,e)=>{try{inbox.Begin();timer.Start();status.Text="等待 Blender 导出……";}catch(Exception ex){status.Text=ex.Message;}};
  stop.Click+=(s,e)=>{timer.Stop();inbox.Stop();status.Text="已暂停接收";};
  send.Click+=(s,e)=>{
   try{
    string current=args.Host.Connector.Pmx.CurrentPath;
    if(String.IsNullOrWhiteSpace(current))throw new IOException("请先在 PE 保存模型，以确定贴图与四边面信息所在目录");
    var model=args.Host.Connector.Pmx.GetCurrentState();string folder=Path.GetDirectoryName(Path.GetFullPath(current));
    foreach(var material in model.Material){material.Tex=Texture(material.Tex,folder);material.Sphere=Texture(material.Sphere,folder);string toon=Texture(material.Toon,folder);if(!String.IsNullOrEmpty(toon)&&File.Exists(toon))material.Toon=toon;}
    string id=ReturnOutbox.Publish(inbox.DirectoryPath,current,path=>model.ToFile(path));
    lastReturn=id;timer.Start();status.Text="已发送回传 "+id.Substring(0,8)+"。Blender 将先备份，再更新原文件中的同步模型。";
   }catch(Exception ex){status.Text="回传失败："+ex.Message;}
  };
  timer.Interval=300;timer.Tick+=(s,e)=>{
   timer.Stop();try{
    string result=inbox.Poll(args.Host.Connector.Pmx.CurrentPath,path=>args.Host.Connector.Form.OpenPMXFile(path));
    if(result=="loaded")status.Text="已读取 Blender 导出。编辑完成后可发送回 Blender。";
    else if(result=="paused")status.Text="PE 切换到其他模型，接收已暂停。";
    else if(result=="rejected"||result=="error")status.Text="接收失败："+inbox.LastError;
    string ackPath=Path.Combine(inbox.DirectoryPath,"return-ack.xml");
    if(lastReturn!=null&&File.Exists(ackPath)&&new FileInfo(ackPath).Length<8192){
     var settings=new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null};
     using(var reader=XmlReader.Create(ackPath,settings)){
      reader.MoveToContent();string id=reader.GetAttribute("id"),state=reader.GetAttribute("status");
      if(reader.Name=="return-ack"&&id==lastReturn){status.Text=reader.ReadElementContentAsString();if(state=="complete"||state=="error")lastReturn=null;}
     }
    }
   }catch(Exception ex){status.Text="同步状态："+ex.Message;}finally{if((inbox.Active||lastReturn!=null)&&!IsDisposed)timer.Start();}
  };
  Controls.AddRange(new Control[]{explanation,start,stop,send,status});FormClosed+=(s,e)=>{timer.Stop();timer.Dispose();inbox.Stop();};
 }
}
