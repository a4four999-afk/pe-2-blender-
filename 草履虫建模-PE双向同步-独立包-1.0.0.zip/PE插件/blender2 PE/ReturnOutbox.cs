using System;
using System.IO;
using System.Text;
using System.Xml;

public static class ReturnOutbox {
 public static string Publish(string exchange,string currentPath,Action<string> save) {
  string id=Guid.NewGuid().ToString("N");
  string directory=Path.Combine(exchange,"returns",id);Directory.CreateDirectory(directory);
  string model=Path.Combine(directory,"model.pmx");
  try {
   save(model);
   using(var f=File.OpenRead(model))if(f.Length<8||f.ReadByte()!=80||f.ReadByte()!=77||f.ReadByte()!=88||f.ReadByte()!=32)throw new IOException("PE 未生成完整 PMX，未发送回传请求");
   string sidecar=Path.ChangeExtension(currentPath,".quads.json");
   if(File.Exists(sidecar))File.Copy(sidecar,Path.Combine(directory,"model.quads.json"));
   string request=Path.Combine(exchange,"return.xml"),temp=Path.Combine(exchange,"return-"+id+".tmp");
   using(var w=XmlWriter.Create(temp,new XmlWriterSettings {Encoding=new UTF8Encoding(false)})) {
    w.WriteStartElement("return");w.WriteAttributeString("id",id);w.WriteAttributeString("model","returns/"+id+"/model.pmx");
    w.WriteAttributeString("source",currentPath);w.WriteEndElement();
   }
   if(File.Exists(request))File.Replace(temp,request,null);else File.Move(temp,request);
   return id;
  } catch {try {Directory.Delete(directory,true);}catch {}throw;}
 }
}
