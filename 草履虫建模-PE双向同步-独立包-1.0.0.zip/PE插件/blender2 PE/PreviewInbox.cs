using System;
using System.IO;
using System.Text;
using System.Xml;

public sealed class PreviewInbox {
 public readonly string DirectoryPath;
 public string ModelPath { get { return Path.Combine(DirectoryPath,"preview.pmx"); } }
 public bool Active { get; private set; }
 public string LastError { get; private set; }
 string seen="";
 bool loaded=false;
 public PreviewInbox(string directory) { DirectoryPath=Path.GetFullPath(directory); }
 string ReadId() {
  string p=Path.Combine(DirectoryPath,"request.xml");
  if(!File.Exists(p))return "";
  if(new FileInfo(p).Length>4096)throw new IOException("请求过大");
  var settings=new XmlReaderSettings { DtdProcessing=DtdProcessing.Prohibit, XmlResolver=null };
  using(var r=XmlReader.Create(p,settings)) {
   r.MoveToContent();
   if(r.Name!="request")throw new IOException("请求格式错误");
   string id=r.GetAttribute("id");
   if(String.IsNullOrEmpty(id)||id.Length>64)throw new IOException("请求编号错误");
   return id;
  }
 }
 public void Begin() { Directory.CreateDirectory(DirectoryPath);seen=ReadId();loaded=false;Active=true; }
 public void Stop() { Active=false; }
 void Ack(string id,string status,string message) {
  string target=Path.Combine(DirectoryPath,"ack.xml"),tmp=target+".tmp";
  using(var w=XmlWriter.Create(tmp,new XmlWriterSettings { Encoding=new UTF8Encoding(false) })) {
   w.WriteStartElement("ack");w.WriteAttributeString("id",id);w.WriteAttributeString("status",status);
   w.WriteString(message??"");w.WriteEndElement();
  }
  if(File.Exists(target))File.Replace(tmp,target,null);else File.Move(tmp,target);
 }
 public string Poll(string currentPath,Func<string,bool> open) {
  if(!Active)return "";
  string id="";
  try {
   id=ReadId();if(id==""||id==seen)return "";
   seen=id;
   if(loaded && (String.IsNullOrWhiteSpace(currentPath) || !String.Equals(Path.GetFullPath(currentPath),ModelPath,StringComparison.OrdinalIgnoreCase))) {
    Active=false;Ack(id,"paused","PE 已切换模型，接收已暂停");return "paused";
   }
   using(var f=File.OpenRead(ModelPath)) {
    if(f.Length<8||f.ReadByte()!=80||f.ReadByte()!=77||f.ReadByte()!=88||f.ReadByte()!=32)
     throw new IOException("预览文件不是完整的 PMX 文件");
   }
   bool ok=open(ModelPath);
   if(ok)loaded=true;
   Ack(id,ok?"loaded":"rejected",ok?"PMX 已重新读取；物理播放请在 PE 中操作":"PE 未完成加载");
   return ok?"loaded":"rejected";
  } catch(Exception ex) {
   LastError=ex.Message;
   if(id!="")try{Ack(id,"error",LastError);}catch{}
   return "error";
  }
 }
}
